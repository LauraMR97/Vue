<template>
  <!--<img alt="Vue logo" src="./assets/logo.png"> -->
  <!--Puedo poner v-vind:start o :start que sería el atajo -->
  <!--<counter start='101'/>-->
  <Indecision/>
</template>

<script>
//import Counter from './components/Counter.vue'
import Indecision from './components/Indecision.vue'

export default {
  name: 'App',
  components: {
     Indecision
    //Counter
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
